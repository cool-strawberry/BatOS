BatOS Instuctions:

1. Extract the ZIP file.

2. When you are done, run BatOS.bat.

3. Once BatOS says you are done, ensure the necessary folders have been created. (Backups, Other, Programs, Storage, System, and Temporary. All inside the BatOS folder in your user profile folder.).

4. If ANY of the things in "C:\Users\YourUsernameHere\BatOS" do not exist, contact "@cool.strawberry" on Discord or go to "https://frostyplayz.wixsite.com/batos".

5. If the folders do not exist, try running BatOS again.

6. If that doesn't work, try running "BatOS Directory Builder.bat" and "BatOS Registry Builder.bat".

7. If NONE of the recovery methods work, reinstall BatOS.

8. You are done! Enjoy BatOS to it's fullest.

Note: BatOS has been scanned by VirusTotal and multiple users have used BatOS. If Windows Defender SmartScreen gives you a warning, right click on BatOS.bat, click Properties, and click "Allow".
Note 2: If you are using this on a VM (virtual machine), please use it on a Windows 10 or 11 one. Some features (like the Browser, as it expects Microsoft Edge installed) may not work if you are running this on Windows 8.1 and below. 